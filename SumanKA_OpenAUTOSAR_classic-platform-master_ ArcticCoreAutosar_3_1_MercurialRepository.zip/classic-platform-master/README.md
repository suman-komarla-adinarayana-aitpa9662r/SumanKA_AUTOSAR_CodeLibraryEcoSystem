This is a fork of the Arctic Core (the open source AUTOSAR embedded platform).

It has been imported from the Arctic Core Autosar 3.1 Mercurial Repository:
http://my.arccore.com/hg/arc/